import socket

from .aes_256_encryption_decryption import AESCipher
from .caesar_cipher import CaesarCipher

host = "127.0.0.1"
port = 8012

phase_1_cipher = CaesarCipher(5)
phase_2_cipher = AESCipher(b'12345678901234567890123456789012')


def run():
    print('Running Client')
    print('Reading FileA')
    with open('FileA', 'rb') as f:
        data = f.read()

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.connect((host, port))
        print(f'Sending to Server : {data}')
        print("Encrypting Data....")
        result_ph1 = phase_1_cipher.encrypt(data)
        print(f'Encrypted Phase 1 : {result_ph1}')
        result_ph2 = phase_2_cipher.encrypt(result_ph1)
        print(f'Encrypted Phase 2 : {result_ph2}')
        sock.sendall(result_ph2)

    print("Client Terminated")
