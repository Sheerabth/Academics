import socket

from .aes_256_encryption_decryption import AESCipher
from .caesar_cipher import CaesarCipher

host = "127.0.0.1"
port = 8012

phase_1_cipher = CaesarCipher(5)
phase_2_cipher = AESCipher(b'12345678901234567890123456789012')


def run():
    print('Running Server')
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind((host, port))
        sock.listen()
        print(f"Listening to port {port}")
        conn, addr = sock.accept()
        with conn:
            print("Connected by ", addr)
            data = conn.recv(1024)
            print(f'Data Received from Client : {data}')
            result_ph2 = phase_2_cipher.decrypt(data)
            print(f'Decrypted Phase 1 : {result_ph2}')
            result_ph1 = phase_1_cipher.decrypt(result_ph2)
            print(f'Decrypted Phase 2 : {result_ph1}')
        with open('FileB', 'wb+') as f:
            f.write(result_ph1)
