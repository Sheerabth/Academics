import sys

args = sys.argv

if len(args) == 2 and args[1][0] == 'c':
    from ps1_module.client import run
else:
    from ps1_module.server import run

run()
